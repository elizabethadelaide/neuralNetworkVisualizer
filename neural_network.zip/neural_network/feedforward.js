function feedforward(){
 this.A_bias = [new bias([0, 1], 0, 0), new bias([2, 3], 1, 0)];
 this.A_input = [new input([0, 1], 0, 1), new input([0, 1], 0, 2)];
 this.A_calc = [new node([2, 3], 1, 1), new node([2, 3], 1, 2), new node([], 2, 1), new node([], 2, 2)];
 this.out = [2, 3];
 this.order = [0, 1, 2, 3]; //layout of layers;
 this.yhat = [];
 
 this.counter = [];
 //console.log("Num of Nodes: " + this.A_calc.length);
 for (var fi = 0; fi < this.A_calc.length; fi++){
   this.counter[fi] = 0;
   console.log("Counter set");
 }
 
 this.calculate = function(){
   //set up inputs
   for (var i = 0; i < this.A_bias.length; i++){
     for (var k = 0; k < this.A_bias[i].connection.length; k++){
       var fn = this.A_bias[i].connection[k];
       this.A_calc[fn].addValue(this.A_bias[i].value, this.counter[fn]);
       this.counter[fn]++;
     }
   }
   for (var i = 0; i < this.A_input.length; i++){
     for (var k = 0; k < this.A_input[i].connection.length; k++){
       var fn = this.A_input[i].connection[k];
       this.A_calc[fn].addValue(this.A_input[i].value, this.counter[fn]);
       this.counter[fn]++;
     }
   }
   //calculate node by node
   for (var b = 0; b < this.order.length; b++){
     i = this.order[b];
     this.A_calc[i].calculate();
     for (var k = 0; k < this.A_calc[i].connection.length; k++){
       var fn = this.A_calc[i].connection[k];
       this.A_calc[fn].addValue(this.A_calc[i].value, this.counter[fn]);
       this.counter[fn]++;
     }
   }
   for (var fi; fi < this.A_calc.length; fi++){
     this.counter[fi] = 0; //reset counters
   }
 }
 this.display = function(){
   for (var i = 0; i < this.A_bias.length; i ++){
     stroke(color(250, 126, 126));
     this.draweach(this.A_bias[i]);
   }
   for (var i = 0; i < this.A_input.length; i ++){
     stroke(color(126, 166, 250));
     this.draweach(this.A_input[i]);
   }
   for (var i = 0; i < this.A_calc.length; i ++){
     stroke(color(146, 250, 126));
     this.draweach(this.A_calc[i]);
   }
 }
 this.inputValues = function(inValues, outValues){
   if (inValues.length != this.A_input.length){
     console.log("ERROR: Wrong number of inputs fed into network");
   }
   else{
     for (var fi = 0; fi < inValues.length; fi++){
       this.A_input[fi].value = inValues[fi];
       
     }
     console.log("About to calculate");
     this.calculate();
     console.log("About to Train");
     this.train(outValues);
   }
  
 }
 
 this.train = function(oV){
  console.log("Length of outputs: " + oV.length);
  if (oV.length != this.out.length){
    console.log("Error: Wrong number of outputs");
  }
  else{
    var error = [];
    for (var i = 0; i < oV.length; i++){
      error[i] = oV[i] - this.A_calc[this.out[i]].value;
      console.log("Error of " + this.out[i] + " node is " + error[i]);
      //text("Error: " + error[i], height/2, width/2);
    }
  }
 }
 this.draweach = function(obj){
   var dx = obj.x*gridsize + gridsize;
   var dy = obj.y*gridsize + gridsize;
   for (var i = 0; i < obj.connection.length; i++){
    var tx = this.A_calc[obj.connection[i]].x*gridsize+gridsize;
    var ty = this.A_calc[obj.connection[i]].y*gridsize+gridsize;
    strokeWeight(1);
    line(dx, dy, tx, ty);
   }
   ellipse(dx, dy, gridsize/2, gridsize/2);
   textSize(12);
   textAlign(CENTER);
   text(nf(obj.value, 1, 3), dx, dy);
 }
 
}