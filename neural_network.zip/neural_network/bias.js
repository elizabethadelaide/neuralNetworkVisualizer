function bias(CONNECTION, tx, ty){
  this.value = 1;
  this.x = tx;
  this.y = ty;
  this.connection = [];
  for (var i = 0; i < CONNECTION.length; i++){
   this.connection[i] = CONNECTION[i]; 
  }
}