gridsize = 100;

sampA = [35, 12, 16, 45, 10];
sampB = [67, 75, 89, 56, 90];
sampC = [1, 0, 1, 1, 0];

function setup() {
  createCanvas(500, 500);
  f = new feedforward();
}

function draw() {
  f.display();
}
function mouseClicked(){
 f.inputValues([sampA[0], sampB[0]], [sampC[0], 1-sampC[0]]); 
}