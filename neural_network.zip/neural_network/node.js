function node(CONNECTION, tx, ty){
  this.x = tx;
  this.y = ty;
  this.connection = [];
  this.weight = [];
  this.input = [];
  this.value = 0;
  for (var i = 0; i < CONNECTION.length; i++){
   this.connection[i] = CONNECTION[i];
  }
  this.sigmoid = function(x){ //sigmoid activation function
    return (1 / (1 + exp(-1*x))); 
  }
  this.addValue = function(tx, n){
    //console.log("INPUTTED: " + tx + ", " + n);
    this.input[n] = tx;
    if (this.weight.length <= n){
     this.weight[n] = random(1.0); 
    }
  }
  this.calculate = function(){
    var sum = 0;
    for (var ni = 0; ni < this.input.length; ni++){
      //console.log(this.weight[ni] + " , " + this.input[ni]);
      sum += this.weight[ni] * this.input[ni];
    }
    //console.log(sum);
    this.value = this.sigmoid(sum);
  }
}