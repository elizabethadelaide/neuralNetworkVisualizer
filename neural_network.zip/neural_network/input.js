function input(CONNECTIONS, tx, ty){
  this.x = tx;
  this.y = ty;
  this.value = 0;
  this.out = 0;
  this.connection = [];
  for (var i = 0; i < CONNECTIONS.length; i++){
    this.connection[i] = CONNECTIONS[i]; 
  }
}