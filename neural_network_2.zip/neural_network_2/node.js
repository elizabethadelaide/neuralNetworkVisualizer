//node controls:
//calculating sigmoid function
//holds a value
//holds an error value
function node(n, code){
  this.number = n;
  this.sum = 0;
  this.value = 0;
  this.error = 0;
  this.expected = 0; //for output nodes
  this.input = false;
  this.bias = false;
  this.hidden = false;
  this.output = false;
  switch (code){
    case 0: //input node
      this.input = true;
      break;
    case 1: //bias mode
      this.bias = true;
      this.value = 1;
      break;
    case 2: //hidden layer
      this.hidden = true;
      break;
    case 3: //output layer
      this.output = true;
      break;
     default: //not used
       break
  }
  this.setColor = function(){
   if(this.input){
    stroke(color(61, 245, 59));
   }
   else if (this.bias){
     stroke(color(210, 59, 245));
   }
   else if(this.hidden){
     stroke(color(59, 110, 245));
   }
   else if(this.output){
     stroke(color(245, 59, 59));
   }
  }
  //actual calculations
  this.setValue = function(value){ //input variable
    this.value = value;
  }
  this.setExpected = function(exp){
    this.expected = exp;
  }
  this.getError(){
    if (this.output){
      this.error = this.expected - this.value;
    }
    if (this.hidden){
      this.error = this.sum;
    }
  }
  this.addWeightedValue = function(wv){ //add w * inValue to sum
    this.sum += wv;
  }
  this.forwardCalc = function(){
   this.value = this.sigmoid();
   //this.sum = 0; //need sum for back propagation
  }
  this.sigmoid = function(){
    return (1 / (1 + exp(-1*this.sum)));
  }
}