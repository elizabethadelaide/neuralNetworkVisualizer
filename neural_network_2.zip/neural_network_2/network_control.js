//manages connections and nodes

function network_control(){
  this.input = [];
  this.bias = [];
  this.hidden = [];
  this.output = [];
  
  this.master = [];
  

  this.position = [];
  
  this.numInputs = 2;
  this.numBias = 2;
  this.numLayers = 1; //number of hidden layers
  this.numHidden = 3;
  this.numOut = 2;
  this.total = this.numInputs + this.numBias + this.numHidden + this.numOut;
  this.connect = new connections(this.total);
  
  //forward propagate through nodes
  this.forwardPropagate = function(){
    //first input nodes
    //gonna do this manually first
    this.input[0].setValue(.35); //data1
    this.input[1].setValue(.72); //data2
    //for each bias and input node
    for (var i = 0; i < 2; i++){ //first two layers
      var thisLayer = this.master[i]; //get layer
      for (var k = 0; k < thisLayer.length; k++){//for each node
        var fn = thisLayer[k].number; //get number of node
        var cons = this.connect.getForward(fn);
        for (m = 0; m < cons.length; m++){ //for each connection
          var weight = cons[m][1];
          var to = cons[m][0];
          this.getNode(to).addWeightedValue(thisLayer[k].value * weight); //add weighted value to node sum
        }
      }
    }
    for (var i = 2; i < this.master.length; i++){ //hidden and output layers
      var thisLayer = this.master[i];
      for (var k = 0; k < thisLayer.length; k++){ //each node in the layer
        var thisNode = thisLayer[k];
        thisNode.forwardCalc(); //get value of node.
        var fn = thisLayer[k].number;
        var cons = this.connect.getForward(fn);
        for (m = 0; m < cons.length;m++){
         var weight = cons[m][1];
         var to = cons[m][0];
         this.getNode(to).addWeightedValue(thisLayer[k].value * weight);
        }
      }
    }
  }
  //backward propagate
  this.backwardPropagate = function(){
    //set expected outputs
    
    //for each node in the hidden layer calculate the error
    //D = SUM(w_mn * D_mn);
    
    //then repropgate through to get new weights
    //w_mn' = w_mn + (D)*(d(sigmoid)(forward sum))*(value of node from forward).
    //update in connections object.
  }
  
  this.getNode = function(n){
    //get node obj from number
    //based on number of each layer
    for (var gni = 0; gni < this.master.length; gni++){
       var gnLayer = this.master[gni];
       if (n < gnLayer.length){ //if within bounds of thislayer
         return gnLayer[n];
       }
       else{
        n -= gnLayer.length;  //try the next layer
       }
    }
  }
  
  this.addLayers = function(){
    var counter = 0; //counts the connections
    var posCounter = 0;
    counter = this.popLayer(counter, this.numBias, this.bias, 1);
    for (var i = 0; i < this.numBias; i++){
      this.position[posCounter] = [i, 0];
      posCounter++;
    }
    counter = this.popLayer(counter, this.numInputs, this.input, 0);
    for (var i = 0; i < this.numInputs; i++){
      this.position[posCounter] = [0, i+1];
      posCounter++;
    }
    counter = this.popLayer(counter, this.numHidden, this.hidden, 2);
    for (var i = 0; i < this.numHidden; i++){
      this.position[posCounter] = [1, i+1];
      posCounter++;
    }
    console.log(counter);
    counter = this.popLayer(counter, this.numOut, this.output, 3);
    for (var i = 0; i < this.numOut; i++){
      this.position[posCounter] = [2, i+1];
      posCounter++;
    }
    //console.log(this.bias);
    for (var i = 0; i < this.bias.length; i++){
      this.bias[i].value = 1; // initialize biases
    }
    this.master = [this.bias, this.input, this.hidden, this.output];
    this.connections();
   
  }
  this.connections = function(){
    for (var i = 0; i < this.master.length-1; i++){ //for each one except output
      if (i != 0){ //not a bias layer
        var thisArray = this.master[i];
        var nextArray = this.master[i+1]; //next array
      }
      else{
        var thisArray = this.master[i];
      }
      for (var k = 0; k < thisArray.length; k++){ //for each node in the first array
        if (i == 0){
          var nextArray = this.master[k+2];
        }
        var thisNode = thisArray[k];
        for (var m = 0; m < nextArray.length; m++){
          var nextNode = nextArray[m];
          this.connect.addConnection(thisNode.number, nextNode.number);
        }
      }
    }
  }
  this.popLayer = function(c, l, ar, code){ //populate a layer
    for (var i = 0; i < l; i++){
      append(ar, new node(c, code));
      c++;
    }
    return c;
  }
  this.display = function(){
    //console.log(this.position);
    var counter = 0;
    //get x and y position of each node, color according to layer
    for (var i = 0; i < this.master.length; i++){
     var layer = this.master[i];
     for (var k = 0; k < layer.length; k++){
       var numNode = counter;
       counter++;
       layer[k].setColor();
       var tx = this.position[numNode][0] * gridsize + gridsize/2;
       var ty = this.position[numNode][1] * gridsize + gridsize/2;
       //console.log("Position: " + tx + " , " + ty);
       
       cons = this.connect.getForward(layer[k].number);
       //console.log("Node " + layer[k].number + " is connnected to: " + cons.length);
       for (var m = 0; m < cons.length; m++){
         strokeWeight(cons[m][1]*4.0+1);
         //console.log("Connected to: " + cons[m][0]);
         var fn = cons[m][0];
         var tx2 = this.position[fn][0]*gridsize + gridsize/2;
         var ty2 = this.position[fn][1]*gridsize + gridsize/2;
         line(tx, ty, tx2, ty2);
       }
       strokeWeight(1); //reset strokeweight
       ellipse(tx+20, ty, gridsize/2, gridsize/2);
       textSize(12);
       text(nf(layer[k].value, 1, 4), tx, ty);
     }
    }
  }
  
}