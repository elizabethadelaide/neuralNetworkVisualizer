//holds location of source and destination
//holds weight

function connections(total){
  this.forward = [];
  this.backward = [];
  this.weights = [];
  this.forCounter = [];
  this.backCounter = [];
  for (var i = 0; i < total; i++){
   this.forCounter[i] = 0;
   this.backCounter[i] = 0;
   this.forward[i] = [];
   this.backward[i] = [];
   this.weights[i] = [];
  }
  this.addConnection = function(from, to){
    console.log("Adding : " + from + " , " + to);
    var w = random(1);
    this.forward[from][this.forCounter[from]] = [to, w];
    this.backward[to][this.backCounter[to]] = [from, w];
    this.forCounter[from]++;
    this.backCounter[to]++;
  }
  this.getForward = function(n){
    return this.forward[n];
  }
}