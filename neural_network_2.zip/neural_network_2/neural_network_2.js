var gridsize = 100; //distance between nodes
var net;
var pause = true;
function setup() {
  createCanvas(1000, 900);
  net = new network_control();
  net.addLayers();
}

function draw() {
  
  if (!pause){
    background(255);
    net.display();
  }
  else{
    text("Paused", 30, 30);
  }
}

function mouseClicked(){
  pause = !pause;
}
function keyPressed(){
  if (keyCode == RIGHT_ARROW){
    net.forwardPropagate();
  }
}